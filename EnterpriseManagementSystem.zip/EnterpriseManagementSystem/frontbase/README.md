
##Steps
npm install

npm run dev

npm run build

npm run build --report

npm run unit

npm run e2e

npm test
```

##This is only a part of the whole project

